package fr.iut.blankproject;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BlankApplicationTests {

	@Test
	void contextLoads() {

		
	}

}
